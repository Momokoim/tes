// ignore_for_file: deprecated_member_use

import 'dart:convert';

// ignore: unused_import
import 'package:flutter/material.dart'  hide Badge;
import 'package:google_fonts/google_fonts.dart';
// ignore: library_prefixes
import 'package:http/http.dart' as myHttp;
import 'package:url_launcher/url_launcher.dart';
// ignore: unnecessary_import
import 'package:url_launcher/url_launcher_string.dart';

import '../../models/menu_model.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});
  
  get menuModel => null;

  @override
  State<HomeScreen> createState() => _HomeScreenState();

  static firstWhere(bool Function(dynamic place) param0) {}
}

class _HomeScreenState extends State<HomeScreen> {
  final String urlMenu =
      "https://script.google.com/macros/s/AKfycbwroGNBpi2f4biKK8DLk3NyU-IbkLM83fjzpM0uysCqAKjPF7zieSU5Gz4vr6ri2b7B/exec";

  Future<List<MenuModel>> getAllData() async {
    List<MenuModel> listMenu = [];
    var response = await myHttp.get(Uri.parse(urlMenu));
    List data = json.decode(response.body);
    

    for (var element in data) {
      listMenu.add(MenuModel.fromJson(element));
    }

    return listMenu;
  }

Future<void> openWebSource() async {
    final Uri url = Uri.parse(widget.menuModel.sourceUrl);
    if (!await launchUrl(url, mode: LaunchMode.externalApplication)) {
      throw Exception('Could not launch $url');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        automaticallyImplyLeading: false,
        shadowColor: Colors.transparent,
        elevation: 0.0,
        title: Container(
          padding: const EdgeInsets.symmetric(horizontal: 10.0),
          child: const Row(
            children: [
              Expanded(
                child: Text('Hai, Chef'),
              ),
            ],
          ),
        ),
      ),
      
      body: SafeArea(
          child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          FutureBuilder(
              future: getAllData(),
              builder: (context, snapshot) {
                if (snapshot.connectionState == ConnectionState.waiting) {
                  return const Center(
                    child: CircularProgressIndicator(),
                  );
                } else {
                  if (snapshot.hasData) {
                    return Expanded(
                      child: ListView.builder(
                          itemCount: snapshot.data!.length,
                          itemBuilder: (context, index) {
                            MenuModel menu = snapshot.data![index];
                            return Padding(
                              padding: const EdgeInsets.symmetric(vertical: 8),
                              child: Row(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Padding(
                                    padding: const EdgeInsets.all(16),
                                    child: Container(
                                      width: 100,
                                      height: 100,
                                      decoration: BoxDecoration(
                                          borderRadius:
                                              BorderRadius.circular(20),
                                          image: DecorationImage(
                                              fit: BoxFit.cover,
                                              image: NetworkImage(menu.image))),
                                    ),
                                  ),
                                  Expanded(
                                    child: Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        Text(
                                          menu.name,
                                          style: GoogleFonts.montserrat(
                                              fontSize: 16,
                                              fontWeight: FontWeight.bold),
                                        ),
                                        const SizedBox(
                                          height: 8,
                                        ),
                                        Text(
                                          menu.description,
                                          textAlign: TextAlign.left,
                                          style: GoogleFonts.montserrat(
                                              fontSize: 13),
                                        ),
                                        const SizedBox(
                                          height: 12,
                                        ),
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                            );
                          }),
                    );
                  } else {
                    return const Center(
                      child: Text("Tidak ada data"),
                    );
                  }
                }
              }),
        ],
      )),
    );
  }
}