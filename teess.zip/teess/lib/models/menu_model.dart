// To parse this JSON data, do
//
//     final menuModel = menuModelFromJson(jsonString);

import 'dart:convert';

List<MenuModel> menuModelFromJson(String str) => List<MenuModel>.from(json.decode(str).map((x) => MenuModel.fromJson(x)));

String menuModelToJson(List<MenuModel> data) => json.encode(List<dynamic>.from(data.map((x) => x.toJson())));

class MenuModel {
    int id;
    String name;
    String description;
    String image;
    List<String> ingredients;
    List<String> step;

    MenuModel({
        required this.id,
        required this.name,
        required this.description,
        required this.image,
        required this.ingredients,
        required this.step,
    });

    factory MenuModel.fromJson(Map<String, dynamic> json) => MenuModel(
        id: json["id"],
        name: json["Name"],
        description: json["description"],
        image: json["image"],
        ingredients: List<String>.from(json["ingredients"].map((x) => x)),
        step: List<String>.from(json["step"].map((x) => x)),
    );

    Map<String, dynamic> toJson() => {
        "id": id,
        "Name": name,
        "description": description,
        "image": image,
        "ingredients": List<dynamic>.from(ingredients.map((x) => x)),
        "step": List<dynamic>.from(step.map((x) => x)),
    };
}
