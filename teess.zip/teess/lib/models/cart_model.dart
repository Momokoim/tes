class CartModel {
  int menuId;
  int quantity;

  CartModel({required this.menuId, required this.quantity});
}