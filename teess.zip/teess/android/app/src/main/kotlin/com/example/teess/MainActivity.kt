package com.example.teess

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
